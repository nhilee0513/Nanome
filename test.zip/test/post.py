a=['title1',['slide1.png','slide2.png']]

with open("template.lua", "r") as f:
    lines=f.readlines()
f.close()

with open("yourmacro.lua","w") as f:
    for line in lines:
        f.write(line)
    f.write("\n")
    f.write("function main()")
    f.write("\n\tclear_all();")
    f.write("\n\tstep(\"%s\");" %a[0])
    f.write("\n\tslide1=Menu_MakeImageFile(\"title1\", Path_Make(\"{{DESKTOP}}/test/slide1.png\"));")
    f.write("\n\tslide2=Menu_MakeImageFile(\"title2\", Path_Make(\"{{DESKTOP}}/test/slide2.png\"));")
    f.write("\n\tMenu_SetVisible(slide1, true);")
    f.write("\n\tMenu_SetVisible(slide2, true);")
    f.write("\n\tSelection_All();")
    f.write("\n\tCommand_Zoom();")
    f.write("\n\ton_close(slide1, slide2);")


    f.write("\n\tstep(\"Your macro has ended\");")
    f.write("\nend;")
f.close()