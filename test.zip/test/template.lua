wait_time = 1000;

function step (text)
    Command_Wait(wait_time / 2);
    Command_Notification(text);
    Command_Wait(wait_time / 2);
end;

function clear_all()
    --step("Closing all menus");
    menus = Menu_FindAll();
    for menu in List_Iterator(menus) do
        Menu_SetVisible(menu, false);
    end;
    --step("Selecting everything (if there is something)");
    Selection_All();
    --step("Delete everything selected");
    atoms = Selection_GetAtoms();
    Command_Delete(atoms);
end;

function command_showDefaults()
    -- This function sets everything to false.
    Command_ShowAtomsBonds(false);
    Command_ShowRibbons(false);
    Command_ShowSurfaces(false);
    Command_ShowWaters(false);
    Command_ShowHydrogens(false);
    Command_ShowHetAtomsBonds(false);
    Command_ShowHetSurfaces(false);
    Command_ShowResidueLabels(false);
    Command_ShowAtomLabels(false);
end;

function on_close(slide1, slide2)
    Menu_SetVisible(slide1, true);
    Menu_SetVisible(slide2, true);
    while (Menu_GetVisible(slide1) and Menu_GetVisible(slide2)) do
    	Command_Wait(1);
    end;
    Menu_Delete(slide1);
    clear_all();
    Menu_Delete(slide2);
    clear_all();
end;


