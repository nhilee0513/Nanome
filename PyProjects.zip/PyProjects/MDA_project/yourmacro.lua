wait_time = 1000;

function step (text)
    Command_Wait(wait_time / 2);
    Command_Notification(text);
    Command_Wait(wait_time / 2);
end;

function clear_all()
    --step("Closing all menus");
    menus = Menu_FindAll();
    for menu in List_Iterator(menus) do
        Menu_SetVisible(menu, false);
    end;
    --step("Selecting everything (if there is something)");
    Selection_All();
    --step("Delete everything selected");
    atoms = Selection_GetAtoms();
    Command_Delete(atoms);
end;

function command_showDefaults()
    -- This function sets everything to false.
    Command_ShowAtomsBonds(false);
    Command_ShowRibbons(false);
    Command_ShowSurfaces(false);
    Command_ShowWaters(false);
    Command_ShowHydrogens(false);
    Command_ShowHetAtomsBonds(false);
    Command_ShowHetSurfaces(false);
    Command_ShowResidueLabels(false);
    Command_ShowAtomLabels(false);
end;



function main()
	clear_all();

	step("Title1");
	slide0=Menu_MakeImageFile("Title1", Path_Make("{{DESKTOP}}/test/slide1.png"));
	Menu_SetVisible(slide0, true);
	slide1=Menu_MakeImageFile("Title1", Path_Make("{{DESKTOP}}/test/slide2.png"));
	Menu_SetVisible(slide1, true);
	Command_Load("mol1.pse","pse","file", Path_Make("{{DESKTOP}}/test/mol1.pse"));
	Command_Load("mol2.pse","pse","file", Path_Make("{{DESKTOP}}/test/mol2.pse"));
	Selection_All();
	Command_Zoom();
	while(Menu_GetVisible(slide0) and Menu_GetVisible(slide1) and true) do
		Command_Wait(1);
	end;
	Menu_Delete(slide0);
	Menu_Delete(slide1);
	clear_all();

	step("Title2");
	slide0=Menu_MakeImageFile("Title2", Path_Make("{{DESKTOP}}/test/slide3.png"));
	Menu_SetVisible(slide0, true);
	slide1=Menu_MakeImageFile("Title2", Path_Make("{{DESKTOP}}/test/slide4.png"));
	Menu_SetVisible(slide1, true);
	Command_Load("mol3.pse","pse","file", Path_Make("{{DESKTOP}}/test/mol3.pse"));
	Command_Load("mol4.pse","pse","file", Path_Make("{{DESKTOP}}/test/mol4.pse"));
	Selection_All();
	Command_Zoom();
	while(Menu_GetVisible(slide0) and Menu_GetVisible(slide1) and true) do
		Command_Wait(1);
	end;
	Menu_Delete(slide0);
	Menu_Delete(slide1);
	clear_all();
	step("Your macro has ended");
end;