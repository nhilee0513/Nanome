import csv
with open("data2.csv", newline='') as f:
    reader=csv.reader(f)
    data = list(reader)

data1=[[j.split(";") for j in i] for i in data]

with open("template.lua", "r") as f:
    lines=f.readlines()
f.close()
with open("yourmacro.lua","w") as f:
    for line in lines:
        f.write(line)
    f.write("\n")
    f.write("function main()")
    f.write("\n\tclear_all();")
    f.write("\n\tmyTable={}")
    f.write("\n\tstep(\"%s\");" %data1[0][0][0])
    for i in range(len(data1[0][1])):
        f.write("\n\tslide%d=Menu_MakeImageFile(\"%s\", Path_Make(\"{{DESKTOP}}/test/%s\"));" %(i,data1[0][0][0],data1[0][1][i]))
        f.write("\n\tMenu_SetVisible(slide%d, true);" %i)
        f.write("\n\tmyTable[%d]=\"slide%d\"" %(i,i))
    f.write("\n\tSelection_All();")
    f.write("\n\tCommand_Zoom();")
    f.write("\n\ton_close(myTable);")


    f.write("\n\tstep(\"Your macro has ended\");")
    f.write("\nend;")
f.close()

